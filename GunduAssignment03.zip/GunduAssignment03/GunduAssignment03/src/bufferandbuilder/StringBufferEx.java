package bufferandbuilder;

public class StringBufferEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuffer strngbuff = new StringBuffer("String Buffer is printing");
		strngbuff.append("....");
		System.out.println(strngbuff);
	}

}
