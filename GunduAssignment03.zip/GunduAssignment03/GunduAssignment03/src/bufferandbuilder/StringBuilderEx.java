package bufferandbuilder;

public class StringBuilderEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StringBuilder strngbuild = new StringBuilder("String Builder is printing");
		strngbuild.append("....");
		System.out.println(strngbuild);
	}

}
