package covariant;

public class Covariant {
	Covariant get(){
		System.out.println("Covariant get method is printing...");
		return this;
	}
}
