package covariant;


public class CovariantReturnType extends Covariant{

	CovariantReturnType get() {
		System.out.println("CovariantReturnType get method is printing...");
		return this;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Covariant obj = new CovariantReturnType();
		obj.get();
	}

}
