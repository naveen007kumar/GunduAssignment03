package finalfinallyfinalize;

public class FinalFinallyFinalize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		final int a = 5;
		
		int b = 6;
		
		try {
			b++;
		}
		
		finally {
			System.out.println("Finally is printing");
		}
		
		
	}
	
	public void finalize() {
		System.out.println("Method is overridden");
	}

}
