package generic;

import java.util.ArrayList;

public class Generics {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<String> al= new ArrayList<String>();
		al.add("Welcome");
		al.add("To");
		al.add("Generics");
		
		String s = al.get(1);
		
		System.out.println(s);
		

	}

}
