package serializable;

import java.io.Serializable;

public class SerializableInterface implements Serializable {
	int num;
	String str;
	public SerializableInterface(int num, String str) {
	// TODO Auto-generated method stub
		this.num = num;
		this.str = str;	
	}
}
