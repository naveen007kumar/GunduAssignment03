package staticandprivate;

public class Car {
	private void ride() {
		System.out.println("Car rides");
	}
	
	static void staticRide() {
		System.out.println("Car Static rides... ");
	}
	
}
