package staticandprivate;

public class CarDriver extends Car{

	void ride() {
		System.out.println("Car Driver rides");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car carObj1 = new CarDriver();
		carObj1.ride();
		
		Car carObj2 = new CarDriver();
		carObj2.ride();;	
	}

}
