package stringandStringbuffer;

public class StringBufferExm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		StringBuffer strbuf = new StringBuffer("Ram is a ");
		strbuf.append("great king");
		System.out.println(strbuf);
	}

}
