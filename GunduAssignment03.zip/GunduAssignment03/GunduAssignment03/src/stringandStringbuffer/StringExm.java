package stringandStringbuffer;

public class StringExm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String str1 = "Ram is a good";
		String str2 = " warrior";
		System.out.println(str1+str2);
		
		
	}

}
