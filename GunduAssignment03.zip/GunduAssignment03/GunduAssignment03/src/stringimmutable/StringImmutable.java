package stringimmutable;

public class StringImmutable {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str = "String is";
		str.concat(" immutable");
		System.out.println(str);
	}

}
