package threadandrunnable;

public class ExtendingThread extends Thread {

	public void run() {
		System.out.println("Running a thread...");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ExtendingThread et = new ExtendingThread();
		et.start();
	}

}
