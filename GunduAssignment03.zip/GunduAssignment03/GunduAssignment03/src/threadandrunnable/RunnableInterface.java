package threadandrunnable;

public class RunnableInterface implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println("Thread is started...");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RunnableInterface ri = new RunnableInterface();
		Thread t = new Thread(ri);
		t.start();
	}

}
