package threadtwice18thQ;

public class ThreadClass extends Thread{

	public void run() {
		System.out.println("Printing in thread...");
	}
	
}
