package threadtwice18thQ;

public class TwiceThread {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadClass tc = new ThreadClass();
		tc.start();
		tc.start();
	}
}
