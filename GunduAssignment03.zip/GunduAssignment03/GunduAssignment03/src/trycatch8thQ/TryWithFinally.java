package trycatch8thQ;

public class TryWithFinally {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			System.out.println("This is try block");
		}
		finally {
			System.out.println("This is finally block");
		}

	}

}
