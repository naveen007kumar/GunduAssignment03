package trywithresource9thQ;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TryWithResource {

	
	public static void main(String args[]) {
		
		try(FileOutputStream fos = new FileOutputStream("trywithresource.txt")){
			
			String str = "This is try with resource";
			int len = str.length();
			fos.write(len);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Hello executed successfully"
				+ "");
		
	}
	
}
